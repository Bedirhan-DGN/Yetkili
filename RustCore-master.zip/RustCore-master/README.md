# RustCore
MineFox Rust Core

# Items
Deagle: 290<br>
Pump-Rifle: 291<br>
M4A1: 292<br>
AK47: 293<br>
RPG: 294<br>
Mine: 151

# Kit
Bandage: 339<br>
Kit: 281

# Crates Key
399: Key

# Commands
Simple Epin<br>
Simple Home<br>
Simple Tag<br>
Simple Economy<br>
Simple Land<br>
Simple BanWarn<br>
Simple Feed<br>
Simple Fly<br>
Simple Kit<br>
Simple Spawn<br>
Advanced Craft<br>
Advanced Friends<br>
Advanced Sell<br>
Advanced Shop

# Extra
Simple Form System<br>
Simple AntiCommand<br>
Advanced Sqlite Database<br>
Advanced Tag System<br>
Advanced Tag Permission
