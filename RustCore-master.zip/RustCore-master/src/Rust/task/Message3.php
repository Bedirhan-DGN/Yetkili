<?php

namespace Rust\task;

use pocketmine\scheduler\Task;
use pocketmine\Server;

class Message3 extends Task{
/*
  public function onRun(int $currentTick){
    foreach (Server::getInstance()->getOnlinePlayers() as $player) {
      $player->sendMessage("§8» §eTaleplerinizi ve Bugları minefox.net sitesinden bize ulaştırın.");
    }
  }*/
}
