<?php

namespace Rust\task;

use pocketmine\scheduler\Task;
use pocketmine\Server;

class Message2 extends Task{
/*
  public function onRun(int $currentTick){
    foreach (Server::getInstance()->getOnlinePlayers() as $player) {
      $player->sendMessage("§8» §eSunucumuza oy vermek için minefox.net sitesini ziyaret edin.");
    }
  }*/
}
